//
//  AppDelegate.h
//  Study_001_01
//
//  Created by 山崎拓也 on 2015/10/27.
//  Copyright (c) 2015年 山崎拓也. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

