//
//  main.m
//  Study_001_01
//
//  Created by 山崎拓也 on 2015/10/27.
//  Copyright (c) 2015年 山崎拓也. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
