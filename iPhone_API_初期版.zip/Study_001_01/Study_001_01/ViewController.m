//
//  ViewController.m
//  Study_001_01
//
//  Created by 山崎拓也 on 2015/10/27.
//  Copyright (c) 2015年 山崎拓也. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
